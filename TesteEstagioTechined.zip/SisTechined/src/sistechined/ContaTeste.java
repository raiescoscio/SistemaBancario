
package sistechined;
/*
 * @author Raí Jhonny Escoscio
 */
                        //  CLASSE PARA TESTE. JÁ COM ESSAS INSTANCIAS P/ VERIFICAR.
public class ContaTeste {
            
    public static void main(String[] args) {
        /*
        ContaPoupanca pessoa1 = new ContaPoupanca(12539, 2186, "Rai Escoscio", "10/03/2017");
        ContaCorrente pessoa2 = new ContaCorrente(41132, 3037, "Rayane Costa", "12/03/2017",1000.00);
        
        pessoa1.depositar(500);
        pessoa2.depositar(800);
        
        pessoa2.transferir(pessoa1, 100);
        
        pessoa1.redimentoMensal();
        
        pessoa1.sacar(200);
        pessoa2.sacar(1200);
       
        
        //Exibir extrato da conta
        pessoa1.mostrarConta();
        pessoa2.mostrarConta(); */
        
        
    }
    
}
